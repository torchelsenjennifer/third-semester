
def titulo(texto, sublinhado="-"):
    print()
    print(texto)
    print(sublinhado*40)
